from setuptools import setup, find_packages

setup(
    name="Asynchronous_chat",
    version="1.0.0",
    packages=find_packages(),
    author="Litvincev Aleksei",
    author_email="lase_star@mail.ru",
    url="https://github.com/LaseStar/-Asynchronous_chat",
)
