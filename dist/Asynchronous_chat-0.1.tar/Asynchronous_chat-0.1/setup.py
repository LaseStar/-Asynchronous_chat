from setuptools import setup

setup(name="Asynchronous_chat",
      version="0.1",
      description="A simple asynchronous chat",
      author="Litvincev Aleksei",
      author_email="lase_star@mail.ru",
      url="https://www.gb.ru",
      packages=["src"]
      )
